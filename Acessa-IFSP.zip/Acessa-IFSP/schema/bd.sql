CREATE TABLE `acessaifsp`.`aluno` 
( `prontuario` INT(7) NOT NULL , `nome` VARCHAR(60) NOT NULL , `curso` VARCHAR(30) NOT NULL , `endereco` VARCHAR(50) NOT NULL , `cidade` VARCHAR(30) NOT NULL , `estado` VARCHAR(2) NOT NULL , `telefone` VARCHAR(15) NOT NULL , `email` VARCHAR(30) NOT NULL , `foto` VARCHAR(200) NULL DEFAULT NULL , `cartao` VARCHAR(10) NULL , PRIMARY KEY (`prontuario`))

CREATE TABLE `acessaifsp`.`registro` ( `id` INT(9) NOT NULL AUTO_INCREMENT , `prontuario` INT(7) NOT NULL , `hora` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , PRIMARY KEY (`id`))

ALTER TABLE `acessaifsp`.`registro` ADD INDEX `prontuario_fk` (`prontuario`);

ALTER TABLE `registro` ADD CONSTRAINT `prontuario_fk` FOREIGN KEY (`prontuario`) REFERENCES `aluno`(`prontuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;




INSERT INTO `aluno` (`prontuario`, `nome`, `curso`, `endereco`, `cidade`, `estado`, `telefone`, `email`, `foto`, `cartao`) VALUES
(1420127, 'Miguel Francelino', 'ADS', 'Av. Minas Gerais 171', 'Sumar�', 'SP', '(19) 99695-2836', 'fabio@acessaifsp.com.br', 'img/miguel.jpg', '');

INSERT INTO `registro` (`id`, `prontuario`, `hora`) VALUES
('', ' 1420127', '2018-06-27 21:18:05');










